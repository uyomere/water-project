$(document).ready(function(){

"use strict";
$('body').scrollspy({
target: '.navbar',
offset: 160

});



});